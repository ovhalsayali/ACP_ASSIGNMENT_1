import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class VoterSrv extends HttpServlet  
{	

public void sanService(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
{
	res.setContentType("text/html");
	PrintWriter out=res.getWriter();

	String name=req.getParameter("pname");
	String sage=req.getParameter("page");
	//writing the form validataion
		if( (name==null) || (name.equals(" ")) ||(name.length()==0))
		{
			out.print("<I> <font color=red>User Name is mandatory</font></I>");
			return;
		}
		if((sage==null)||(sage.equals(" "))||(sage.length()==0))
		{
			out.print("<I> <font color=red>Age is mandatory</font></I>");
			return;
		}
	
	int age=0;
		try
		{

		age=Integer.parseInt(sage);
		}
		catch(NumberFormatException nfe)
		{
			out.print("<I> <font color=red>Age must be in numaric</font></I>");
			return;
		}

	if(age>=18)
	{
		out.print("<B><i><font size=25 color=green>You Are Eligible To Vote</Font></i></b>");
		
	}
	else 
	{
		out.print("<B><i><font size=25 color=red>You Are Not Eligible To Vote</Font></i></b><br>");
		
	}

	out.print("<br><a href=Vote.html><img src=Tulips.jpg height=100 width=100></img></a>");
	
}
public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
sanService(req,res);
	}
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
sanService(req,res);
	}
}
